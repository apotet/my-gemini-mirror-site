# VERIFICATION_REPORT — NetOps L3 Batch 3 (Issue #442)

- **Verified `main` HEAD SHA:** `00babda1781a893e4648f81e9bc4211ddc437765`
- **Generated:** 2026-11-26

| Проверка | Статус | Детали |
|---|---|---|
| Соответствие фактической схеме `Lesson` актуального `main` | **PASS (structural)** | Строгий whitelist полей `Lesson`, `LessonBlock`, `LessonCheatsheet`, `LessonCommand`, `LessonKnowledgeCheck`, `LessonQuestion` пройден для 5/5 файлов; 0 неподдерживаемых полей, 0 выдуманных `practiceLink`. |
| Исключение дублей Batch 1 (`3ce4599`), Batch 2 (`#410`) и PR `#352` | **PASS** | Проверен `src/data/lessons/index.ts` на `00babda`; проверены 5 смежных уроков и `GROUP1_LINKS..GROUP5_LINKS` (0 конфликтов). |
| Сверка точных текстов и ключей всех 11 вопросов | **PASS** | Все 11 условий/ответов/ключей прочитаны напрямую из `src/data/questions.json` и `src/data/questionsExtraDifficulty.ts`. |
| 11 индивидуальных anchors без конфликтов heading | **PASS (structural)** | 11/11 уникальных `anchorId`, 100% точное совпадение `afterHeading.plain` и `afterHeading.professional`. |
| Самопроверки 35/35 и распределение A–D | **PASS** | A=9, B=8, C=9, D=9; 35 уникальных ID; все 4 буквы A–D в каждом уроке. |
| Глоссарий (11 новых ключей без коллизий, 0 dead controls) | **PASS** | 11 новых ключей проверены 0/0 в `src/data/glossary.ts` (`CRC` на `:541` не дублирован); все `terms` покрыты карточками. |
| XML-валидация и PNG-проверка 5 SVG | **PASS** | XML 5/5, убраны проблемные Unicode `✓`/`✗`, все 5 PNG проверены визуально (пойман и исправлен 1 наезд текста в `l3-tcp-wscale-keepalive.svg`). |
| Полный grep 11 ID по всем 78 файлам `src/data/lessons/*.ts` | **UNVERIFIED** | Глобальный GitHub code search требует логина; проверены 5 наиболее смежных уроков + все `GROUP1..5_LINKS`. Интегратору прогнать `grep` перед merge. |
| `tsc --noEmit`, `npm run lint` и `npm run build` в изолированной копии репозитория | **UNVERIFIED** | В sandbox нет исходящего интернета и локального клона репозитория; GitHub строго read-only. |
| Runtime-проверка `GLOSSARY` (с `IN_DEPTH_TERMS`), anchors и рендер 1440/375 px в Chromium | **UNVERIFIED** | Требует выполнения в интегрированной staging-ветке. |
| Владельческая приёмка (`USER_APPROVED`) | **UNVERIFIED** | Присваивается только владельцем отдельно. |
