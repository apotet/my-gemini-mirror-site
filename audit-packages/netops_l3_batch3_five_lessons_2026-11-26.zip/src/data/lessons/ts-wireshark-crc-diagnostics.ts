import type { Lesson } from './types';

export const LESSON_TS_WIRESHARK_CRC_DIAGNOSTICS: Lesson = {
  "id": "ts-wireshark-crc-diagnostics",
  "title": "Диагностика трафика и линков: фильтры Wireshark и delta-оценка CRC",
  "category": "Диагностика · Wireshark и интерфейсы",
  "osiLayers": [
    "L1",
    "L2",
    "L3",
    "L4"
  ],
  "difficulty": "applied",
  "summary": "Точные display-фильтры Wireshark для поиска TCP-ретрансмиссий и двустороннего трафика хоста, а также методика оценки текущих CRC-ошибок по разности двух снимков без сброса статистики.",
  "terms": [
    "Display Filter",
    "CRC",
    "TCP",
    "IPv4"
  ],
  "blocks": [
    {
      "heading": "Поиск повторных передач TCP в Wireshark: tcp.analysis.retransmission",
      "body": "Когда пользователи жалуются на тормоза и подвисания, первый шаг при анализе дампа трафика — проверить, теряются ли пакеты по пути. Чтобы показать TCP-пакеты, которые анализатор Wireshark отметил как повторные передачи, используется display filter:\n`tcp.analysis.retransmission`\n\nНе путай его с другими флагами: `tcp.flags.reset == 1` показывает разрывы RST, `tcp.flags.syn == 1` — начало соединений, а `tcp.window_size == 0` — заполнение буфера приёмника (Zero Window).",
      "cheatsheet": {
        "file": "l3-wireshark-crc-delta.svg",
        "title": "Wireshark Display Filters (retransmission / ip.addr) и delta-оценка счётчиков CRC",
        "alt": "Схема базовых display-фильтров Wireshark (tcp.analysis.retransmission, ip.addr == 10.1.1.10, осторожность с отрицанием) и метода двух снимков ΔCRC за интервал нагрузки.",
        "note": "Display filter фильтрует уже открытый дамп; capture filter (BPF, например `host 10.1.1.10`) задаётся до начала записи."
      },
      "cheatsheetInitiallyOpen": true
    },
    {
      "heading": "Фильтрация трафика с участием хоста: ip.addr против ip.src и ip.dst",
      "body": "Чтобы увидеть **все** пакеты с участием IPv4-адреса `10.1.1.10` в обе стороны (и исходящие от него, и входящие к нему), применяй фильтр:\n`ip.addr == 10.1.1.10`\n\nФильтр `ip.src == 10.1.1.10` покажет только исходящие пакеты (половину диалога), а `ip.dst == 10.1.1.10` — только входящие. Фильтры удобно комбинировать: `ip.addr == 10.1.1.10 && tcp.analysis.retransmission`.",
      "relatedLesson": {
        "id": "ts-method",
        "label": "Повторить общую методику пошаговой сетевой диагностики"
      }
    },
    {
      "heading": "Как понять, растут ли ошибки CRC сейчас, не сбрасывая счётчики",
      "body": "Частая ситуация (`ts-pack1-07`): на обоих концах линка уже согласован `full-duplex`, но мониторинг всё равно показывает много накопленных ошибок CRC за неделю. Нужно выяснить, появляются ли повреждения **прямо сейчас**, НЕ сбрасывая статистику (`clear counters`) и НЕ меняя параметры линии.\n\nПравильный инженерный метод — **вычесть два снимка счётчика CRC за известный интервал под нагрузкой (`ΔCRC = CRC(t2) − CRC(t1)`)**. Деление накопленных CRC на весь uptime или на общее число кадров с запуска порта размазывает старую аварию по истории и не отвечает на вопрос, исправен ли канал сейчас.",
      "relatedLesson": {
        "id": "l1-copper-fault-poe",
        "label": "Посмотреть физические причины повреждений на медной линии"
      }
    }
  ],
  "professional": {
    "summary": "Экспертный анализ TCP в Wireshark (`tcp.analysis.retransmission`, `ip.addr`, ловушка `!=`), методика delta-снимков счётчиков CRC без `clear counters` и локализация L1-дефектов.",
    "terms": [
      "Display Filter",
      "CRC",
      "TCP",
      "IPv4"
    ],
    "blocks": [
      {
        "heading": "Поиск повторных передач TCP в Wireshark: tcp.analysis.retransmission (tr-06)",
        "body": "• **`tr-06` (`tcp.analysis.retransmission`):** выделяет сегменты, классифицированные эвристикой Wireshark как повторные передачи (включая RTO и fast retransmit). Для полной картины потерь часто дополнительно смотрят `tcp.analysis.fast_retransmission` и `tcp.analysis.duplicate_ack`.\n• **`tr-07` (`ip.addr == 10.1.1.10`):** эквивалентен `(ip.src == 10.1.1.10 || ip.dst == 10.1.1.10)` и сохраняет полный двусторонний диалог, необходимый анализатору TCP для отслеживания ACK и потерь.\n\n**Классическая ловушка отрицания:** выражение `ip.addr != 10.1.1.10` почти всегда истинно (так как второй IP в пакете не равен `10.1.1.10`!). Для исключения узла всегда пиши `!(ip.addr == 10.1.1.10)`.",
        "cheatsheet": {
          "file": "l3-wireshark-crc-delta.svg",
          "title": "Шпаргалка: Wireshark Display Filters и delta-диагностика CRC",
          "alt": "Ключевые display-фильтры Wireshark и расчёт ΔCRC по двум снимкам без сброса статистики.",
          "note": "Не путай синтаксис Display Filter (Wireshark: `ip.addr == 10.1.1.10`) и Capture Filter (BPF/tcpdump: `host 10.1.1.10`)."
        },
        "cheatsheetInitiallyOpen": true
      },
      {
        "heading": "Двусторонний display-фильтр ip.addr и ловушка отрицания != (tr-07)",
        "body": "Фильтр **`ip.addr == 10.1.1.10`** (`tr-07`) эквивалентен `(ip.src == 10.1.1.10 || ip.dst == 10.1.1.10)` и сохраняет полный двусторонний обмен, необходимый TCP-анализатору для корректного сопоставления SEQ/ACK и поиска потерь.\n\n**Ловушка отрицания:** выражение `ip.addr != 10.1.1.10` почти всегда истинно (так как второй IP-адрес в пакете не равен `10.1.1.10`). Чтобы исключить узел, всегда используй `!(ip.addr == 10.1.1.10)`."
      },
      {
        "heading": "Delta-оценка счётчиков CRC без сброса статистики (ts-pack1-07)",
        "body": "Накопительные (monotonic) счётчики интерфейсов — стандарт в SNMP и CLI. Сброс счётчиков (`clear counters`) часто запрещён политикой эксплуатации, так как ломает базовые линии мониторинга и лишает смежников истории.\n\nВ сценарии `ts-pack1-07` (full-duplex уже согласован, но накоплено много CRC за неделю) единственно корректная неинвазивная оценка — **снять два значения счётчика CRC за известный интервал нагрузки (Δt) и вычислить их разность `ΔCRC = CRC(t2) − CRC(t1)`** (при желании соотнеся с `Δpackets` за тот же интервал). Среднее по всему uptime (`CRC / uptime`), доля по всем кадрам с запуска и сравнение накопленных итогов двух концов не отделяют прошлый инцидент от текущего состояния. Если при согласованном `full-duplex` `ΔCRC > 0`, проверяй физику L1: кабель/обжим, загрязнение торцов оптики, уровни Rx/Tx SFP (DOM) и электромагнитные наводки."
      }
    ],
    "commands": [
      {
        "title": "Комбинированный display-фильтр потерь хоста (Wireshark)",
        "cmd": "ip.addr == 10.1.1.10 && tcp.analysis.retransmission",
        "note": "Показывает повторные передачи TCP с участием 10.1.1.10 в обе стороны."
      },
      {
        "title": "Снятие двух снимков счётчиков ошибок без сброса (Linux)",
        "cmd": "ip -s link show dev eth0 && sleep 60 && ip -s link show dev eth0",
        "note": "Вычти значения `RX errors / crc` между вторым и первым выводом за 60 с нагрузки; на NIC с ethtool также смотри `ethtool -S eth0`."
      },
      {
        "title": "Снятие снимка CRC на коммутаторе (Cisco IOS/IOS-XE — пример)",
        "cmd": "show interfaces Gi1/0/1 | include CRC|packets input",
        "note": "Повтори через фиксированный интервал нагрузки без `clear counters` и вычисли ΔCRC."
      }
    ],
    "sources": [
      "Wireshark User's Guide — Building Display Filter Expressions and TCP Analysis",
      "IEEE Std 802.3 — Ethernet FCS / CRC Error Counters"
    ]
  },
  "relatedQuestionIds": [
    "tr-06",
    "tr-07",
    "ts-pack1-07"
  ],
  "plainKnowledgeCheck": {
    "title": "Проверь себя: Wireshark и CRC — простыми словами",
    "intro": "Три вопроса по display-фильтрам и оценке счётчиков.",
    "questions": [
      {
        "id": "l3-ws-plain-01",
        "prompt": "Какой display filter в Wireshark покажет все пакеты с участием IPv4-адреса 10.1.1.10 (и входящие, и исходящие)?",
        "choices": [
          {
            "id": "A",
            "label": "ip.src == 10.1.1.10"
          },
          {
            "id": "B",
            "label": "ip.addr == 10.1.1.10"
          },
          {
            "id": "C",
            "label": "ip.dst == 10.1.1.10"
          },
          {
            "id": "D",
            "label": "tcp.flags.syn == 1"
          }
        ],
        "correctChoiceId": "B",
        "explanation": "`ip.addr == 10.1.1.10` охватывает оба направления (источник и назначение), тогда как `ip.src` или `ip.dst` покажут лишь одну сторону."
      },
      {
        "id": "l3-ws-plain-02",
        "prompt": "Какой display filter в Wireshark выделит пакеты, отмеченные анализатором как повторные передачи TCP?",
        "choices": [
          {
            "id": "A",
            "label": "tcp.flags.reset == 1"
          },
          {
            "id": "B",
            "label": "tcp.window_size == 0"
          },
          {
            "id": "C",
            "label": "arp.dst.proto_ipv4 == 10.1.1.10"
          },
          {
            "id": "D",
            "label": "tcp.analysis.retransmission"
          }
        ],
        "correctChoiceId": "D",
        "explanation": "`tcp.analysis.retransmission` отбирает сегменты, помеченные TCP-анализатором Wireshark как повторные передачи."
      },
      {
        "id": "l3-ws-plain-03",
        "prompt": "Как узнать, растут ли ошибки CRC на порту прямо сейчас, не сбрасывая статистику?",
        "choices": [
          {
            "id": "A",
            "label": "Разделить общее число CRC за неделю на uptime порта"
          },
          {
            "id": "B",
            "label": "Перезагрузить коммутатор"
          },
          {
            "id": "C",
            "label": "Снять два значения счётчика CRC через известный интервал под нагрузкой и вычесть первое из второго"
          },
          {
            "id": "D",
            "label": "Сравнить накопленные CRC с соседним VLAN"
          }
        ],
        "correctChoiceId": "C",
        "explanation": "Разность двух снимков `CRC(t2) − CRC(t1)` за интервал нагрузки показывает текущую скорость ошибок без сброса статистики."
      }
    ]
  },
  "knowledgeCheck": {
    "title": "Проверь себя: Wireshark и диагностика CRC — по делу",
    "intro": "Четыре инженерных сценария по анализу дампов и счётчиков.",
    "questions": [
      {
        "id": "l3-ws-pro-01",
        "prompt": "Какой display filter Wireshark покажет TCP-пакеты, отмеченные анализатором как повторные передачи?",
        "choices": [
          {
            "id": "A",
            "label": "tcp.analysis.retransmission"
          },
          {
            "id": "B",
            "label": "tcp.flags.reset == 1"
          },
          {
            "id": "C",
            "label": "tcp.flags.syn == 1"
          },
          {
            "id": "D",
            "label": "tcp.window_size == 0"
          }
        ],
        "correctChoiceId": "A",
        "explanation": "`tcp.analysis.retransmission` — стандартный фильтр анализатора Wireshark для повторных передач TCP."
      },
      {
        "id": "l3-ws-pro-02",
        "prompt": "Как отфильтровать пакеты с участием IPv4-адреса 10.1.1.10 в Wireshark в обе стороны?",
        "choices": [
          {
            "id": "A",
            "label": "ip.src == 10.1.1.10"
          },
          {
            "id": "B",
            "label": "ip.dst == 10.1.1.10"
          },
          {
            "id": "C",
            "label": "ip.addr == 10.1.1.10"
          },
          {
            "id": "D",
            "label": "arp.dst.proto_ipv4 == 10.1.1.10"
          }
        ],
        "correctChoiceId": "C",
        "explanation": "`ip.addr == 10.1.1.10` совпадает как с `ip.src`, так и с `ip.dst`, сохраняя двусторонний поток."
      },
      {
        "id": "l3-ws-pro-03",
        "prompt": "После согласования full-duplex на обоих концах мониторинг всё ещё показывает много CRC за неделю. Как оценить, появляются ли повреждения сейчас, не сбрасывая статистику и не меняя линию?",
        "choices": [
          {
            "id": "A",
            "label": "Разделить накопленные CRC на всё время работы порта"
          },
          {
            "id": "B",
            "label": "Вычесть два снимка CRC за известный интервал нагрузки"
          },
          {
            "id": "C",
            "label": "Сравнить накопленные CRC двух концов соединения"
          },
          {
            "id": "D",
            "label": "Разделить итог CRC на итог кадров с запуска порта"
          }
        ],
        "correctChoiceId": "B",
        "explanation": "Только delta двух снимков за контролируемый интервал нагрузки отделяет свежие повреждения от накопленной истории."
      },
      {
        "id": "l3-ws-pro-04",
        "prompt": "Почему display filter `ip.addr != 10.1.1.10` в Wireshark НЕ исключает пакеты узла 10.1.1.10?",
        "choices": [
          {
            "id": "A",
            "label": "Потому что Wireshark не поддерживает оператор отрицания"
          },
          {
            "id": "B",
            "label": "Потому что `ip.addr` работает только для IPv6"
          },
          {
            "id": "C",
            "label": "Потому что пакеты 10.1.1.10 кэшируются в DNS"
          },
          {
            "id": "D",
            "label": "Потому что в каждом пакете два IP-адреса, и второй адрес не равен 10.1.1.10 — для исключения нужно писать `!(ip.addr == 10.1.1.10)`"
          }
        ],
        "correctChoiceId": "D",
        "explanation": "Условие `ip.addr != X` истинно, если хотя бы один из двух адресов (src или dst) не равен X; корректное отрицание — `!(ip.addr == 10.1.1.10)`."
      }
    ]
  },
  "sources": [
    "Wireshark User's Guide — Display Filters & TCP Analysis",
    "IEEE Std 802.3 — Ethernet FCS / CRC"
  ]
};
