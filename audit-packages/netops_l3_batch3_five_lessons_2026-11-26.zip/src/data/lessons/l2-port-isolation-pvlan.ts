import type { Lesson } from './types';

export const LESSON_L2_PORT_ISOLATION_PVLAN: Lesson = {
  "id": "l2-port-isolation-pvlan",
  "title": "Изоляция портов L2 и Private VLAN: защита хостов в одном VLAN",
  "category": "L2 · Безопасность коммутации",
  "osiLayers": [
    "L2"
  ],
  "difficulty": "applied",
  "summary": "Как изолировать клиентские порты друг от друга внутри одного VLAN (Port Isolation / Isolated PVLAN), сохранив ARP и IP к общему uplink-шлюзу G и независимость от смены MAC-адресов.",
  "terms": [
    "Port Isolation",
    "Private VLAN",
    "VLAN",
    "ARP",
    "ACL"
  ],
  "blocks": [
    {
      "heading": "Зачем изолировать порты внутри одного VLAN",
      "body": "В гостевом Wi-Fi, отеле, дата-центре или офисной подсети десятки ПК находятся в одном VLAN и одной IP-подсети. По умолчанию коммутатор свободно пересылает между ними broadcast (включая ARP) и unicast-кадры, что открывает путь для ARP-спуфинга и сканирования соседей.\n\nЗадача (`ts-pack1-12`): ПК **A** и **B** подключены к одному коммутатору, **G** — общий uplink к шлюзу. Требуется:\n1. ARP и IP к G проходят от обоих ПК;\n2. широковещательный и L2-обмен A↔B НЕ проходит;\n3. замена MAC-адреса у ПК не меняет результат.\n\nЭту матрицу полностью реализует **изоляция портов A и B друг от друга (Port Isolation / Protected Port / Isolated PVLAN)** при сохранении G как общего uplink (promiscuous).",
      "cheatsheet": {
        "file": "l3-port-isolation-pvlan.svg",
        "title": "Изоляция портов L2 (Port Isolation / Isolated PVLAN) против Community PVLAN, PACL и MAC-фильтров",
        "alt": "Схема коммутатора с изолированными портами A и B, общим uplink G (ARP/IP OK, A<->B заблокирован) и сравнение четырёх подходов настройки.",
        "note": "Изоляция привязана к физическим/логическим портам коммутатора, поэтому смена сетевой карты или MAC-адреса её не обходит."
      },
      "cheatsheetInitiallyOpen": true
    },
    {
      "heading": "Почему Community PVLAN, IP PACL и фильтры MAC-пар не подходят",
      "body": "Разберём три частых ошибочных варианта для этой же матрицы:\n• **Одна Community PVLAN для A и B:** порты внутри одной community-группы как раз МОГУТ обмениваться кадрами между собой (включая broadcast) — условие изоляции A↔B нарушено!\n• **IP PACL с разрешённым ARP:** запрещает IP-пакеты между A и B, но пропускает ARP и L2-широковещание между ними.\n• **Фильтр по MAC-парам A→B и B→A:** привязан к текущим MAC-адресам; достаточно сменить MAC на ПК, и запрет перестанет работать.",
      "relatedLesson": {
        "id": "l2-vlan-security",
        "label": "Повторить другие механизмы защиты L2 и VLAN"
      }
    }
  ],
  "professional": {
    "summary": "Port Isolation (Protected Port), Private VLAN (RFC 5517: Primary, Isolated, Community, Promiscuous), сравнение с PACL/MAC ACL и диагностика на коммутаторах.",
    "terms": [
      "Port Isolation",
      "Private VLAN",
      "VLAN",
      "ARP",
      "ACL"
    ],
    "blocks": [
      {
        "heading": "Port Isolation и Private VLAN (RFC 5517): матрица пересылки L2 (ts-pack1-12)",
        "body": "На одном коммутаторе простейшим решением служит **Port Isolation / Switchport Protected** (изоляция L2-пересылки между отмеченными портами с сохранением обмена с обычным uplink G). Если изоляцию нужно масштабировать на несколько коммутаторов, применяют **Private VLAN (RFC 5517)** с тремя ролями:\n• **Isolated Secondary VLAN:** изолированные порты не могут передавать никакой L2-трафик (unicast, multicast, broadcast/ARP) друг другу — только на Promiscuous-порт.\n• **Community Secondary VLAN:** порты внутри одной community-группы обмениваются друг с другом и с Promiscuous, но изолированы от других community/isolated групп.\n• **Promiscuous Port (uplink G):** обменивается со всеми портами Primary VLAN.\n\nВ условии `ts-pack1-12` только включение изоляции портов A и B друг от друга (с общим uplink G) удовлетворяет всем трём требованиям одновременно: пропускает ARP/IP к G, блокирует broadcast A↔B и не зависит от смены MAC-адресов.",
        "cheatsheet": {
          "file": "l3-port-isolation-pvlan.svg",
          "title": "Матрица доступа L2: Isolated vs Community PVLAN, PACL и MAC-фильтрация",
          "alt": "Сравнение Port Isolation / Isolated PVLAN с Community PVLAN, IP PACL и MAC-фильтрами.",
          "note": "Учитывай: если шлюз G включит Local Proxy ARP на SVI, A и B смогут общаться на L3 через G (при отсутствии L3 ACL) — проверяй политику на шлюзе."
        },
        "cheatsheetInitiallyOpen": true
      },
      {
        "heading": "Кейс и границы применимости: локальная изоляция против межузлового трафика",
        "body": "**Нюанс 1 (один коммутатор vs несколько):** `switchport protected` (Port Isolation) действует строго в пределах одного коммутатора. Если ПК A на Switch 1, а ПК B на Switch 2, трафик через общий trunk между коммутаторами не заблокируется простым `protected` — для межузловой изоляции нужен Private VLAN (RFC 5517).\n\n**Нюанс 2 (L3-обход через шлюз):** L2-изоляция закрывает прямой обмен A↔B на коммутаторе, но если на шлюзе G разрешён Local Proxy ARP и нет L3 ACL, трафик A→G→B может пройти на уровне L3. Поэтому для полной изоляции клиентов L2 Port Isolation дополняют политикой на маршрутизаторе G.",
        "relatedLesson": {
          "id": "l2-access-guard",
          "label": "Повторить защиту портов доступа (DHCP Snooping и Port Security)"
        }
      }
    ],
    "commands": [
      {
        "title": "Включение локальной изоляции портов (Cisco IOS/IOS-XE — пример)",
        "cmd": "interface range Gi1/0/1 - 2\n switchport protected\nshow interfaces Gi1/0/1 switchport",
        "note": "Изолирует отмеченные порты друг от друга на одном коммутаторе; uplink G остаётся без `switchport protected`. Сверь синтаксис на целевой ОС."
      },
      {
        "title": "Проверка Private VLAN (Cisco IOS/IOS-XE / NX-OS — пример)",
        "cmd": "show vlan private-vlan",
        "note": "Показывает Primary VLAN, Secondary (Isolated/Community) и привязанные порты; поддержка зависит от модели и лицензии."
      },
      {
        "title": "Изоляция портов в Linux bridge (iproute2)",
        "cmd": "bridge link set dev vethA isolated on\nbridge link set dev vethB isolated on",
        "note": "Изолированные порты bridge общаются только с неизолированным uplink-портом G."
      }
    ],
    "sources": [
      "RFC 5517 — Cisco Systems' Private VLANs: Scalable Security in a Multi-Client Environment",
      "Linux iproute2 Manual — bridge(8) (isolated port flag)"
    ]
  },
  "relatedQuestionIds": [
    "ts-pack1-12"
  ],
  "plainKnowledgeCheck": {
    "title": "Проверь себя: изоляция портов L2 — простыми словами",
    "intro": "Три вопроса по Port Isolation и Private VLAN.",
    "questions": [
      {
        "id": "l3-pvlan-plain-01",
        "prompt": "Почему для запрета обмена между ПК A и B на одном коммутаторе (при сохранении доступа к шлюзу G) изоляция портов лучше фильтрации по MAC-адресам?",
        "choices": [
          {
            "id": "A",
            "label": "Фильтрация по MAC не работает в Ethernet"
          },
          {
            "id": "B",
            "label": "Изоляция портов автоматически шифрует трафик TLS"
          },
          {
            "id": "C",
            "label": "Изоляция портов отключает шлюз G"
          },
          {
            "id": "D",
            "label": "Изоляция действует на уровне самих портов и не обходится при смене MAC-адреса на ПК"
          }
        ],
        "correctChoiceId": "D",
        "explanation": "Port Isolation / Isolated PVLAN привязан к портам коммутатора, поэтому смена MAC-адреса или сетевой карты не нарушает изоляцию."
      },
      {
        "id": "l3-pvlan-plain-02",
        "prompt": "Чем Isolated PVLAN отличается от Community PVLAN?",
        "choices": [
          {
            "id": "A",
            "label": "В Isolated порты не могут общаться друг с другом вообще (только с Promiscuous), а внутри одной Community-группы порты могут общаться между собой"
          },
          {
            "id": "B",
            "label": "В Community запрещён доступ к шлюзу G"
          },
          {
            "id": "C",
            "label": "Isolated работает только поверх Wi-Fi"
          },
          {
            "id": "D",
            "label": "Разницы нет — это синонимы"
          }
        ],
        "correctChoiceId": "A",
        "explanation": "По RFC 5517 Isolated-порты полностью изолированы друг от друга, а порты одной Community PVLAN свободно обмениваются трафиком между собой."
      },
      {
        "id": "l3-pvlan-plain-03",
        "prompt": "Почему запрет взаимного IP через PACL (с разрешённым ARP) не закрывает требование запретить широковещательный обмен A↔B?",
        "choices": [
          {
            "id": "A",
            "label": "Потому что PACL работает только для IPv6"
          },
          {
            "id": "B",
            "label": "Потому что PACL блокирует доступ к шлюзу G"
          },
          {
            "id": "C",
            "label": "Потому что ARP и другие L2-широковещательные кадры всё равно будут проходить между A и B"
          },
          {
            "id": "D",
            "label": "Потому что ARP передаётся поверх TCP"
          }
        ],
        "correctChoiceId": "C",
        "explanation": "Разрешённый ARP является L2 broadcast-обменом: хосты A и B продолжат видеть широковещательные кадры друг друга."
      }
    ]
  },
  "knowledgeCheck": {
    "title": "Проверь себя: Port Isolation и Private VLAN — по делу",
    "intro": "Четыре инженерных сценария по изоляции L2.",
    "questions": [
      {
        "id": "l3-pvlan-pro-01",
        "prompt": "ПК A и B на одном коммутаторе, G — общий uplink. Нужно: ARP/IP к G проходят от обоих, широковещательный обмен A↔B не проходит, смена MAC не меняет результат. Какой вариант реализует всю матрицу?",
        "choices": [
          {
            "id": "A",
            "label": "Поместить A и B в одну community PVLAN, G сделать promiscuous"
          },
          {
            "id": "B",
            "label": "Включить изоляцию портов A и B друг от друга, оставив G общим uplink"
          },
          {
            "id": "C",
            "label": "На A и B запретить взаимный IP через PACL, оставив ARP разрешённым"
          },
          {
            "id": "D",
            "label": "Запретить MAC-пары A→B и B→A"
          }
        ],
        "correctChoiceId": "B",
        "explanation": "Только Port Isolation / Isolated PVLAN блокирует весь L2-обмен (включая broadcast/ARP) между A и B, пропускает A↔G и B↔G и не зависит от смены MAC."
      },
      {
        "id": "l3-pvlan-pro-02",
        "prompt": "ПК A подключён к Switch 1, а ПК B — к Switch 2 (соединены обычным trunk). Почему локальный `switchport protected` на обоих коммутаторах не изолирует A от B?",
        "choices": [
          {
            "id": "A",
            "label": "Потому что `switchport protected` работает только на скорости 100 Мбит/с"
          },
          {
            "id": "B",
            "label": "Потому что trunk-порты не передают VLAN ID"
          },
          {
            "id": "C",
            "label": "Потому что `switchport protected` действует только в пределах одного коммутатора; для межузловой изоляции нужен Private VLAN (RFC 5517)"
          },
          {
            "id": "D",
            "label": "Потому что ARP не ходит между коммутаторами"
          }
        ],
        "correctChoiceId": "C",
        "explanation": "Локальный protected-флаг не передаётся по стандартному 802.1Q trunk; для изоляции между разными коммутаторами используют Isolated Secondary VLAN в PVLAN."
      },
      {
        "id": "l3-pvlan-pro-03",
        "prompt": "После включения L2 Port Isolation на коммутаторе ПК A всё равно смог пропинговать ПК B через шлюз G. Что наиболее вероятно включено на шлюзе G?",
        "choices": [
          {
            "id": "A",
            "label": "Local Proxy ARP на интерфейсе шлюза G при отсутствии запрещающего L3 ACL"
          },
          {
            "id": "B",
            "label": "Отключён протокол STP"
          },
          {
            "id": "C",
            "label": "Включён TCP Window Scale"
          },
          {
            "id": "D",
            "label": "Изменена маска подсети на /31"
          }
        ],
        "correctChoiceId": "A",
        "explanation": "Local Proxy ARP позволяет шлюзу G отвечать на ARP-запросы за изолированных хостов и маршрутизировать их трафик на L3."
      },
      {
        "id": "l3-pvlan-pro-04",
        "prompt": "Какую роль должен иметь порт шлюза G в архитектуре Private VLAN (RFC 5517), чтобы обмениваться трафиком со всеми изолированными хостами?",
        "choices": [
          {
            "id": "A",
            "label": "Isolated"
          },
          {
            "id": "B",
            "label": "Community"
          },
          {
            "id": "C",
            "label": "Discarding"
          },
          {
            "id": "D",
            "label": "Promiscuous"
          }
        ],
        "correctChoiceId": "D",
        "explanation": "Promiscuous-порт в Private VLAN имеет право общаться со всеми портами Primary VLAN, включая Isolated и Community."
      }
    ]
  },
  "sources": [
    "RFC 5517 — Private VLANs",
    "Linux iproute2 — bridge(8)"
  ]
};
