import type { Lesson } from './types';

export const LESSON_L4_TCP_OPTIONS_KEEPALIVE: Lesson = {
  "id": "l4-tcp-options-keepalive",
  "title": "TCP-опции: Window Scale (RFC 7323) и Keepalive для простаивающих соединений",
  "category": "L4 · Транспорт и TCP",
  "osiLayers": [
    "L4"
  ],
  "difficulty": "applied",
  "summary": "Правило взаимного согласования TCP Window Scale в SYN и SYN-ACK (RFC 7323) и границы возможностей TCP Keepalive на простаивающем соединении без данных в полёте.",
  "terms": [
    "TCP",
    "Window Scale",
    "TCP Keepalive",
    "HTTP",
    "SYN"
  ],
  "blocks": [
    {
      "heading": "Согласование Window Scale: почему опция должна быть и в SYN, и в SYN-ACK",
      "body": "В базовом заголовке TCP поле `Window` занимает 16 бит (максимум 65 535 байт), чего мало для быстрых каналов с заметной задержкой. Опция **Window Scale** (RFC 7323) задаёт сдвиг `shift` (множитель `2^shift`), но действует строгое правило: **масштабирование включается только если ОБЕ стороны прислали опцию Window Scale в SYN и SYN-ACK**.\n\n**Пример (`l4-new-06`):** узел A отправил `SYN` с `Window Scale = 7`, но узел B **не включил** `Window Scale` в `SYN-ACK`. Позже A объявил `Window = 1000` в обычном `ACK`. Поскольку согласование не состоялось, множитель `2^7 = 128` НЕ применяется — B обязан учитывать окно ровно **`1000 байт`** (а не 128 000 и не 7 000).",
      "cheatsheet": {
        "file": "l3-tcp-wscale-keepalive.svg",
        "title": "TCP Window Scale (SYN + SYN-ACK) и контроль idle-соединения через TCP Keepalive",
        "alt": "Схема отказа согласования Window Scale при отсутствии опции в SYN-ACK (окно остаётся 1000 байт) и сравнение TCP Keepalive с RTO, HTTP Connection: keep-alive и SO_RCVTIMEO.",
        "note": "Если одна сторона не хочет масштабировать своё окно, но поддерживает опцию, она шлёт Window Scale = 0 в SYN/SYN-ACK."
      },
      "cheatsheetInitiallyOpen": true
    },
    {
      "heading": "Простаивающее TCP-соединение и «тихий» обрыв: что реально даёт TCP Keepalive",
      "body": "Представь, что приложение держит открытое простаивающее TCP-соединение без неподтверждённых данных в полёте, а сетевой путь к peer молча пропал (например, завис NAT или оборвался канал без RST/FIN). Как обнаружить это без пользовательских запросов?\n\n• **Настроенный TCP Keepalive** периодически шлёт пустые проверочные зонды после простоя и **может обнаружить неотвечающий путь или упавший peer, но НЕ гарантирует здоровье самого приложения** (ядро ОС может исправно отвечать ACK на зонды, даже если процесс приложения завис в deadlock).\n• **Почему не подходят альтернативы:** сокращение RTO срабатывает только когда есть неподтверждённые данные в полёте; `HTTP Connection: keep-alive` лишь держит сокет открытым для повторных запросов и не шлёт фоновых проверок; `SO_RCVTIMEO` — это лишь таймаут ожидания вызова `recv()`, который сработает и на живом простаивающем соединении, когда peer просто ничего не слал.",
      "relatedLesson": {
        "id": "tcp-window-retransmit",
        "label": "Повторить механику TCP-окна и повторных передач (RTO / SACK)"
      }
    }
  ],
  "professional": {
    "summary": "RFC 7323 §2.2 (взаимное согласование Window Scale и границы 14 бит), RFC 9293 §3.8.4 (TCP Keepalive: tcp_keepalive_time/intvl/probes) и разграничение с app-level heartbeat.",
    "terms": [
      "TCP",
      "Window Scale",
      "TCP Keepalive",
      "HTTP",
      "SYN"
    ],
    "blocks": [
      {
        "heading": "Правило согласования TCP Window Scale (RFC 7323 §2.2 — l4-new-06)",
        "body": "Согласно RFC 7323 §2.2, опция Window Scale (Kind=3, максимальный сдвиг `shift.cnt = 14`, множитель до `2^14 = 16384`) передаётся **только** в сегментах `SYN` и `SYN-ACK`. Включить масштабирование в одностороннем порядке невозможно: если `SYN` содержит `WS=7`, а `SYN-ACK` вообще не содержит опцию `Window Scale`, обе стороны устанавливают сдвиг равным `0` для всего соединения.\n\nВ сценарии `l4-new-06` объявленное позднее `Window = 1000` в обычном `ACK` интерпретируется узлом B буквально как **`1000 байт`**. Также учти диагностическую ловушку Wireshark: если захват трафика начался уже ПОСЛЕ `SYN/SYN-ACK`, анализатор не знает согласованный `shift` и показывает не масштабированное значение окна!",
        "cheatsheet": {
          "file": "l3-tcp-wscale-keepalive.svg",
          "title": "RFC 7323 (Window Scale) и RFC 9293 (TCP Keepalive) на простаивающем сокете",
          "alt": "Диаграмма взаимного согласования WS в SYN/SYN-ACK и границ применения TCP Keepalive.",
          "note": "Для точного анализа окна в Wireshark всегда захватывай исходный TCP 3-way handshake (SYN / SYN-ACK)."
        },
        "cheatsheetInitiallyOpen": true
      },
      {
        "heading": "TCP Keepalive (RFC 9293 §3.8.4) против RTO, HTTP keep-alive и SO_RCVTIMEO (l4-new-08)",
        "body": "В сценарии `l4-new-08` на простаивающем TCP-соединении (нет данных в полёте) таймер ретрансмиссий (**RTO**) вообще не запущен, поэтому его сокращение бесполезно. Заголовок `HTTP Connection: keep-alive` управляет лишь переиспользованием соединения и не генерирует сетевых зондов. `SO_RCVTIMEO` ограничивает время блокировки `recv()` и не отличает «peer молчит, потому что нет данных» от «путь оборвался».\n\n**Настроенный TCP Keepalive** (`SO_KEEPALIVE` + параметры `TCP_KEEPIDLE`, `TCP_KEEPINTVL`, `TCP_KEEPCNT`; системные defaults в Linux часто велики — например, 7200 с, поэтому их настраивают под задачу) отправляет зонд с `SEQ = SND.NXT − 1` и при отсутствии ответов разрывает мёртвое соединение. Однако он проверяет только доступность **стека TCP/IP удалённого ядра**, а не работоспособность прикладного процесса — для проверки живости сервиса нужен прикладной heartbeat (например, HTTP/2 PING, gRPC keepalive или app-level ping).",
        "relatedLesson": {
          "id": "l4-tcp",
          "label": "Повторить установление соединения TCP (SYN / SYN-ACK / ACK)"
        }
      }
    ],
    "commands": [
      {
        "title": "Проверка системных параметров TCP Keepalive и Window Scaling (Linux)",
        "cmd": "sysctl net.ipv4.tcp_window_scaling net.ipv4.tcp_keepalive_time net.ipv4.tcp_keepalive_intvl net.ipv4.tcp_keepalive_probes",
        "note": "Показывает глобальные настройки ядра Linux; отдельные приложения могут переопределять keepalive через setsockopt()."
      },
      {
        "title": "Просмотр активных таймеров keepalive на сокетах (Linux)",
        "cmd": "ss -to state established",
        "note": "Флаг -o выводит активные таймеры TCP (`timer:(keepalive,...)`), подтверждая, включён ли keepalive на конкретном соединении."
      },
      {
        "title": "Фильтр Wireshark для Window Scale и Keepalive",
        "cmd": "tcp.options.wscale || tcp.analysis.keep_alive",
        "note": "Позволяет проверить наличие Window Scale в SYN/SYN-ACK и факт отправки TCP keepalive-зондов."
      }
    ],
    "sources": [
      "RFC 7323 — TCP Extensions for High Performance (Section 2 TCP Window Scale Option)",
      "RFC 9293 — Transmission Control Protocol (TCP) (Section 3.8.4 TCP Keep-Alives)"
    ]
  },
  "relatedQuestionIds": [
    "l4-new-06",
    "l4-new-08"
  ],
  "plainKnowledgeCheck": {
    "title": "Проверь себя: TCP Window Scale и Keepalive — простыми словами",
    "intro": "Три вопроса по согласованию опций и простаивающим соединениям.",
    "questions": [
      {
        "id": "l3-tcpopt-plain-01",
        "prompt": "При каком условии в TCP-соединении начинает действовать масштабирование окна (Window Scale)?",
        "choices": [
          {
            "id": "A",
            "label": "Только если обе стороны включили опцию Window Scale в SYN и SYN-ACK"
          },
          {
            "id": "B",
            "label": "Достаточно, чтобы опцию прислал только инициатор в SYN"
          },
          {
            "id": "C",
            "label": "Оно включается автоматически после передачи 1 МБ данных"
          },
          {
            "id": "D",
            "label": "Оно работает только при включённом HTTP Connection: keep-alive"
          }
        ],
        "correctChoiceId": "A",
        "explanation": "По RFC 7323 опция Window Scale требует взаимного подтверждения в SYN и SYN-ACK; в одностороннем порядке она не активируется."
      },
      {
        "id": "l3-tcpopt-plain-02",
        "prompt": "Отправляет ли заголовок `HTTP Connection: keep-alive` фоновые сетевые зонды для проверки, не оборвался ли путь к серверу?",
        "choices": [
          {
            "id": "A",
            "label": "Да: он шлёт ICMP-пинги каждую секунду"
          },
          {
            "id": "B",
            "label": "Да: он полностью заменяет TCP Keepalive"
          },
          {
            "id": "C",
            "label": "Нет: он лишь разрешает повторно использовать открытое TCP-соединение для следующих запросов"
          },
          {
            "id": "D",
            "label": "Нет: он всегда закрывает TCP сразу после ответа"
          }
        ],
        "correctChoiceId": "C",
        "explanation": "HTTP keep-alive и TCP keepalive — разные механизмы на разных уровнях: HTTP-заголовок не выполняет фоновой проверки доступности peer."
      },
      {
        "id": "l3-tcpopt-plain-03",
        "prompt": "Гарантирует ли ответ удалённого узла на зонд TCP Keepalive, что само прикладное ПО (например, база данных) не зависло?",
        "choices": [
          {
            "id": "A",
            "label": "Да: TCP Keepalive выполняет SQL-запрос внутри приложения"
          },
          {
            "id": "B",
            "label": "Нет: на TCP Keepalive отвечает сетевой стек ядра ОС, даже если процесс приложения завис"
          },
          {
            "id": "C",
            "label": "Да: если есть ACK на keepalive, приложение гарантированно здорово"
          },
          {
            "id": "D",
            "label": "Нет: TCP Keepalive работает только по UDP"
          }
        ],
        "correctChoiceId": "B",
        "explanation": "TCP Keepalive проверяет доступность пути и TCP-стека ядра peer, но для проверки живости самого приложения нужен прикладной heartbeat."
      }
    ]
  },
  "knowledgeCheck": {
    "title": "Проверь себя: TCP Window Scale и Keepalive — по делу",
    "intro": "Четыре инженерных сценария по RFC 7323 и RFC 9293.",
    "questions": [
      {
        "id": "l3-tcpopt-pro-01",
        "prompt": "A отправил SYN с Window Scale=7, но B не включил Window Scale в SYN-ACK. Позже A объявил Window=1000 в обычном ACK. Какое окно A должен учитывать B?",
        "choices": [
          {
            "id": "A",
            "label": "128000 байт"
          },
          {
            "id": "B",
            "label": "7000 байт"
          },
          {
            "id": "C",
            "label": "32768000 байт"
          },
          {
            "id": "D",
            "label": "1000 байт"
          }
        ],
        "correctChoiceId": "D",
        "explanation": "Без опции Window Scale в SYN-ACK масштабирование не согласовано, поэтому B учитывает буквальное значение поля Window = 1000 байт."
      },
      {
        "id": "l3-tcpopt-pro-02",
        "prompt": "Приложение держит простаивающее TCP-соединение без неподтверждённых данных; путь к peer молча пропал. Нужно обнаруживать это без пользовательских запросов. Какой вывод корректен?",
        "choices": [
          {
            "id": "A",
            "label": "Сокращение RTO позволит проверять peer на простаивающем соединении без данных в полёте"
          },
          {
            "id": "B",
            "label": "HTTP Connection: keep-alive задаёт фоновую проверку TCP и обнаружит обрыв"
          },
          {
            "id": "C",
            "label": "Настроенный TCP keepalive может обнаружить неотвечающий путь/peer, но не гарантирует здоровье приложения"
          },
          {
            "id": "D",
            "label": "Истечение SO_RCVTIMEO означает отказ peer, даже когда данные от него не ожидались"
          }
        ],
        "correctChoiceId": "C",
        "explanation": "RTO не работает без данных в полёте, HTTP keep-alive не шлёт зондов, SO_RCVTIMEO — просто таймаут чтения. Только настроенный TCP keepalive зондирует простаивающий путь (не гарантируя здоровье приложения)."
      },
      {
        "id": "l3-tcpopt-pro-03",
        "prompt": "Почему в дампе Wireshark, захваченном ПОСЛЕ установления TCP-соединения, отображаемый размер окна может казаться заниженным?",
        "choices": [
          {
            "id": "A",
            "label": "Потому что анализатор не видел SYN/SYN-ACK и не знает согласованный множитель Window Scale"
          },
          {
            "id": "B",
            "label": "Потому что Wireshark всегда делит окно на 128"
          },
          {
            "id": "C",
            "label": "Потому что Window Scale передаётся только в пакетах FIN"
          },
          {
            "id": "D",
            "label": "Потому что после SYN-ACK окно всегда равно 1000 байт"
          }
        ],
        "correctChoiceId": "A",
        "explanation": "Опция Window Scale передаётся исключительно в SYN и SYN-ACK; без захвата handshake анализатор видит только сырое 16-битное поле Window."
      },
      {
        "id": "l3-tcpopt-pro-04",
        "prompt": "Какой командой в Linux можно быстро проверить, включён ли таймер keepalive на установленных TCP-сокетах?",
        "choices": [
          {
            "id": "A",
            "label": "ip rule show"
          },
          {
            "id": "B",
            "label": "ss -to state established"
          },
          {
            "id": "C",
            "label": "dig +short TXT keepalive"
          },
          {
            "id": "D",
            "label": "bridge link show"
          }
        ],
        "correctChoiceId": "B",
        "explanation": "Опция `-o` в `ss -to` отображает активные TCP-таймеры (включая `keepalive`) на установленных соединениях."
      }
    ]
  },
  "sources": [
    "RFC 7323 — TCP Extensions for High Performance",
    "RFC 9293 — Transmission Control Protocol (TCP)"
  ]
};
