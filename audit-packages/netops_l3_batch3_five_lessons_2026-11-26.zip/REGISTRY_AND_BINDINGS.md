# REGISTRY_AND_BINDINGS — NetOps L3 Batch 3 (Issue #442)

- **Актуальный проверенный `main` SHA:** `00babda1781a893e4648f81e9bc4211ddc437765`
- **Задача:** https://github.com/apotet/my-gemini-mirror-site/issues/442
- **Исключения соблюдены:** 0 пересечений с Batch 1 (`3ce4599` / `#409`), Batch 2 (`#410`/`#419`/`#437`), PR `#352` и всеми существующими уроками `main`.

## 1. Импорты в `src/data/lessons/index.ts`

```ts
import { LESSON_L7_HTTP_FRAMING_RANGES_ETAG } from './l7-http-framing-ranges-etag';
import { LESSON_L3_LINUX_POLICY_ROUTING } from './l3-linux-policy-routing';
import { LESSON_L2_PORT_ISOLATION_PVLAN } from './l2-port-isolation-pvlan';
import { LESSON_L4_TCP_OPTIONS_KEEPALIVE } from './l4-tcp-options-keepalive';
import { LESSON_TS_WIRESHARK_CRC_DIAGNOSTICS } from './ts-wireshark-crc-diagnostics';
```

## 2. Индивидуальные привязки (11 вопросов → 11 уникальных `anchorId`, 0 конфликтов heading)

| Урок (`lessonId`) | `questionIds` | `anchorId` | `afterHeading.plain` | `afterHeading.professional` |
| :--- | :--- | :--- | :--- | :--- |
| `l7-http-framing-ranges-etag` | `['l7-new-05']` | `http-chunked-trailers` | `Transfer-Encoding: chunked и завершение сообщения с trailers` | `Грамматика chunked-тела (RFC 9112 §7.1): last-chunk и trailer-section` |
| `l7-http-framing-ranges-etag` | `['gap-pack2-13']` | `http-206-content-range` | `Докачка файла: 206 Partial Content и Content-Range` | `Диапазоны байт 206 Content-Range и контроль версии (RFC 9110 §14)` |
| `l7-http-framing-ranges-etag` | `['gap-pack3-14']` | `http-etag-if-match-412` | `Оптимистичная блокировка: ETag, If-Match и ответ 412` | `Условные обновления ETag / If-Match и 412 Precondition Failed (RFC 9110 §13)` |
| `l3-linux-policy-routing` | `['ts-pack1-11']` | `linux-ip-route-get-from` | `Как проверить решение ядра для пары (from → dst) без изменения настроек` | `Запрос решения ядра: синтаксис ip route get и селекторы (ts-pack1-11)` |
| `l3-linux-policy-routing` | `['ts-pack1-13']` | `linux-ip-rule-table-priority` | `Почему default в таблице 100 побеждает /32 в таблице 200` | `Приоритет таблиц RPDB против Longest Prefix Match (ts-pack1-13)` |
| `l2-port-isolation-pvlan` | `['ts-pack1-12']` | `l2-port-isolation-matrix` | `Зачем изолировать порты внутри одного VLAN` | `Port Isolation и Private VLAN (RFC 5517): матрица пересылки L2 (ts-pack1-12)` |
| `l4-tcp-options-keepalive` | `['l4-new-06']` | `tcp-window-scale-negotiation` | `Согласование Window Scale: почему опция должна быть и в SYN, и в SYN-ACK` | `Правило согласования TCP Window Scale (RFC 7323 §2.2 — l4-new-06)` |
| `l4-tcp-options-keepalive` | `['l4-new-08']` | `tcp-keepalive-idle-peer` | `Простаивающее TCP-соединение и «тихий» обрыв: что реально даёт TCP Keepalive` | `TCP Keepalive (RFC 9293 §3.8.4) против RTO, HTTP keep-alive и SO_RCVTIMEO (l4-new-08)` |
| `ts-wireshark-crc-diagnostics` | `['tr-06']` | `wireshark-tcp-retransmission` | `Поиск повторных передач TCP в Wireshark: tcp.analysis.retransmission` | `Поиск повторных передач TCP в Wireshark: tcp.analysis.retransmission (tr-06)` |
| `ts-wireshark-crc-diagnostics` | `['tr-07']` | `wireshark-ip-addr-filter` | `Фильтрация трафика с участием хоста: ip.addr против ip.src и ip.dst` | `Двусторонний display-фильтр ip.addr и ловушка отрицания != (tr-07)` |
| `ts-wireshark-crc-diagnostics` | `['ts-pack1-07']` | `interface-crc-delta-snapshots` | `Как понять, растут ли ошибки CRC сейчас, не сбрасывая счётчики` | `Delta-оценка счётчиков CRC без сброса статистики (ts-pack1-07)` |
