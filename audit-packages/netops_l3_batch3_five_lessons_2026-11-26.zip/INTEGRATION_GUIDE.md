# INTEGRATION_GUIDE — Интеграция третьей пятёрки уроков L3 (Issue #442)

- **Staging-репозиторий:** `https://github.com/apotet/my-gemini-mirror-site` (production `apotet/netops` и `PR #352` не трогать).
- **Базовый `main` SHA:** `00babda1781a893e4648f81e9bc4211ddc437765`
- **Статус бейджа:** жёлтый («Проверить точечно») до личной приёмки владельца (`USER_APPROVED` не выставлять).

## Шаги интеграции
1. Снять baseline на `main`: `npx tsc --noEmit && npm run lint && npm run build`.
2. Скопировать 5 файлов `src/data/lessons/*.ts` (строго в фактической схеме `Lesson` актуального `main`) и 5 схем `public/lesson-images/*.svg`.
3. Добавить 5 импортов и записей в `LESSONS` в `src/data/lessons/index.ts`.
4. Добавить 11 индивидуальных записей из `REGISTRY_AND_BINDINGS.md` в `src/data/lessons/existingUnderstandingHeadings.ts` (и при необходимости в `IN_DEPTH_LESSON_LINKS` после проверки grep по всем `src/data/lessons/*.ts`).
5. Добавить 11 новых ключей из `GLOSSARY_ADDITIONS.json` (`newGlossaryEntries` и `newTooltipNames`) в `src/data/glossary.ts` (`CRC` уже есть на `:541` — не дублировать!).
6. Прогнать итоговые `npx tsc --noEmit`, `npm run lint`, `npm run build`, адресный тест всех 11 `questionId → lessonId + anchorId`, проверку runtime `GLOSSARY` (включая `IN_DEPTH_TERMS`) и браузерный рендер (1440 px / 375 px).
