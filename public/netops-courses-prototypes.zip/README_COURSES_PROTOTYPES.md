# NetOps Academy — Интерактивный прототип топологии и профессиональной эволюции

Содержимое архива:
- `src/courses-prototypes/concepts/ConceptAcademy.tsx` — NetOps Academy: 18 направлений, сквозные треки безопасности и диагностики, развилка из 8 IT-профессий, выделение персонального пути с приглушением некритичных узлов, честное разделение «Только теория / Практика / Подтверждено», масштаб и мобильный метро-маршрут.
- `src/courses-prototypes/data/academyTopologyData.ts` — граф компетенций, роли и калькулятор переносимости навыков.
- `src/courses-prototypes/concepts/ConceptStudio.tsx`, `ConceptTextbook.tsx` — сохранённые ранние концепции.
- `src/courses-prototypes/components/` — общие виджеты (визуализатор масок IPv4/IPv6, мост возврата к урокам/стендам, итоговый тест).
- `src/assets/images/courses_*` и `index.html`.
